/**
 * Creates demo SageMess accounts when they are not already present.
 * Admin:  admin@sagemess.local / sage123
 * Student: student@sagemess.local / sage123
 */
require('dotenv').config();

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const User = require('./app/modules/user/user.model');
const Mess = require('./app/modules/mess/mess.model');
const Menu = require('./app/modules/menu/menu.model');
const Announcement = require('./app/modules/announcement/announcement.model');

const ADMIN_EMAIL = 'admin@sagemess.local';
const STUDENT_EMAIL = 'student@sagemess.local';
const PASSWORD = 'sage123';

async function run() {
    await mongoose.connect(process.env.DB_URL, { useNewUrlParser: true });

    let admin = await User.findOne({ email: ADMIN_EMAIL });
    let messId = admin ? admin.messId : null;

    if (!admin) {
        const mess = await Mess.create({ messusername: 'sagemess' });
        messId = mess._id;
        admin = await User.create({
            email: ADMIN_EMAIL,
            username: 'Priya Nair',
            password: bcrypt.hashSync(PASSWORD, 10),
            phone: '9876543210',
            messId,
            role: 'admin',
        });
        console.log('Created admin', ADMIN_EMAIL);
    } else {
        console.log('Admin already exists');
    }

    const student = await User.findOne({ email: STUDENT_EMAIL });
    if (!student) {
        await User.create({
            email: STUDENT_EMAIL,
            username: 'Arjun Das',
            password: bcrypt.hashSync(PASSWORD, 10),
            phone: '9123456780',
            rollNumber: 'B423045',
            department: 'CSE',
            hostel: 'Hostel 2',
            roomNumber: '214',
            messId,
            role: 'user',
        });
        console.log('Created student', STUDENT_EMAIL);
    } else {
        console.log('Student already exists');
    }

    const monday = await Menu.findOne({ messId, day: 'Monday' });
    if (!monday) {
        await Menu.create({
            messId,
            day: 'Monday',
            breakfast: ['Poha', 'Banana', 'Tea'],
            lunch: ['Rice', 'Dal', 'Seasonal vegetable', 'Curd'],
            snacks: ['Samosa', 'Tea'],
            dinner: ['Roti', 'Paneer curry', 'Salad'],
            specialNote: 'Extra curd on request.',
            updatedBy: admin._id,
        });
        console.log('Created Monday menu');
    }

    const noticeCount = await Announcement.countDocuments({ messId });
    if (noticeCount === 0) {
        await Announcement.create({
            messId,
            title: 'Mess timing',
            message: 'Breakfast 7:30–9:30, Lunch 12:30–2:30, Snacks 5:00–6:00, Dinner 8:00–9:30.',
            createdBy: admin._id,
        });
        console.log('Created sample notice');
    }

    await mongoose.disconnect();
}

run().catch((error) => {
    console.error(error);
    process.exit(1);
});
