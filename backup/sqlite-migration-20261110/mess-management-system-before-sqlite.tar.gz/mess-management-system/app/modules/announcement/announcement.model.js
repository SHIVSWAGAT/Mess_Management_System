const mongoose = require('mongoose');

const announcementSchema = new mongoose.Schema(
    {
        messId: {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            index: true,
        },
        title: {
            type: String,
            required: true,
            trim: true,
            maxlength: 120,
        },
        message: {
            type: String,
            required: true,
            trim: true,
            maxlength: 500,
        },
        createdBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'user',
        },
    },
    {
        timestamps: true,
        versionKey: false,
    }
);

module.exports = mongoose.model('announcement', announcementSchema);
